-- formstats - pick a statistical object (from the template's Statistics
-- tab) and a chart shape; the chart widget draws it over the active
-- template's data. Everything reads index-backed aggregates via
-- formidable.statistical (no body scan).
--
-- The form (form.json) holds two dropdown fields (object, shape) and a
-- chart widget. Two commands drive it:
--   refresh  on_change   re-options the shape field for the picked
--                        object's rank (run.options)
--   draw     form button evaluates the object and pushes the chart to
--                        the widget (run.chart)

-- refresh(ctx) is the on-change handler: it runs whenever a form field
-- changes (and once on open) so the shape dropdown only ever offers
-- shapes the picked object can actually be. It evaluates the object,
-- reads the grid's rank (number of axes), and steers the "shape" field
-- via formidable.run.options: rank-1 -> bar/pie, rank-2 -> heatmap,
-- rank-0 -> scalars. The host re-selects a valid value if the current
-- one drops out.
function refresh(ctx)
  local tpl = ctx and ctx.template
  if not tpl or tpl == "" or not ctx.object or ctx.object == "" then
    return { ok = true }
  end
  local g = formidable.statistical.eval(tpl, ctx.object)
  local rank = #(g.axes or {})
  if rank >= 2 then
    formidable.run.options("shape", { { value = "heatmap", label = "Heatmap" } })
  elseif rank == 1 then
    formidable.run.options("shape", {
      { value = "bar", label = "Bar" },
      { value = "pie", label = "Pie" },
    })
  else
    formidable.run.options("shape", { { value = "scalars", label = "Scalars" } })
  end
  return { ok = true }
end

-- draw(ctx) is the "Draw chart" form button. ctx carries the form
-- fields: ctx.object (selected statistical object), ctx.shape (chart
-- shape) and ctx.template (active template). It evaluates the object
-- and STEERS the chart widget by pushing a spec via
-- formidable.run.chart - the same live-widget mechanism as
-- run.bar / run.status. The widget (a passive wrapper) renders it.
function draw(ctx)
  local tpl = ctx and ctx.template
  if not tpl or tpl == "" then
    formidable.toast.warn(formidable.i18n.t("toast.no_template"))
    return { ok = false }
  end
  if not ctx.object or ctx.object == "" then
    formidable.toast.info(formidable.i18n.t("toast.no_object"))
    return { ok = true }
  end
  -- Pass the template's facets so the chart colors categories with the
  -- facets' authored option colors (same palette as the facet pills),
  -- instead of the default rotation.
  local t = formidable.template.get(tpl)
  formidable.run.chart({
    type = ctx.shape,
    result = formidable.statistical.eval(tpl, ctx.object),
    facets = t.facets,
  })
  return { ok = true }
end
