-- formstats - chart-neutral statistics over the active template, drawn
-- entirely from the index DB via formidable.stats.* and
-- formidable.facets.* (both read index-backed aggregates; no body scan).
--
-- ctx.template is fed by the Storage / Templates workspace selection.
-- We read the template definition for its facets, fields and table
-- columns, then emit one chart envelope per chartable thing:
--
--   facets       distribution bar per facet  + cross-tab per facet pair
--   number/range numeric summary cards        (stats.numeric)
--   date         monthly time-series line     (stats.timeSeries)
--   dropdown     value distribution bar        (stats.distribution)
--   radio        value distribution bar        (stats.distribution)
--   multioption  value distribution bar        (stats.distribution)
--   boolean      true/false distribution bar   (stats.distribution)
--   table cols   same routing per column, addressed by column index
--
-- Each envelope carries { type?, title, result }. The host dispatches
-- the renderer by the result's `kind` (StatChart), so `type` is only
-- set where we want to override (cross-tabs render stacked).

local PERCENTILE = 90      -- extra scalar card on numeric summaries
local MAX_CROSS  = 6       -- cap facet-pair cross-tabs so dialogs stay sane

-- Field types that route to each stat call.
local NUMERIC_TYPES = { number = true, range = true }
local DISTRIB_TYPES = { dropdown = true, radio = true, multioption = true, boolean = true }

-- ── result guards ────────────────────────────────────────────────────
-- The stat builders always return a Result table; these decide whether
-- it carries renderable data so empty fields/columns don't add blanks.

local function has_categories(result)
  return type(result) == "table"
    and type(result.categories) == "table"
    and #result.categories > 0
end

local function has_scalars(result)
  if type(result) ~= "table" or type(result.scalars) ~= "table" then
    return false
  end
  -- count is always present; treat count==0 as "nothing measured".
  local count = result.scalars.count
  if count ~= nil and count == 0 then
    return false
  end
  return next(result.scalars) ~= nil
end

-- ── title helpers ────────────────────────────────────────────────────
-- Prefix keys live in the plugin's i18n map (chart.* ); fall back to the
-- key verbatim when a locale is missing (i18n.t's own contract).

local function prefixed(prefix_key, label)
  local prefix = formidable.i18n.t(prefix_key)
  if label and label ~= "" then
    return prefix .. ": " .. label
  end
  return prefix
end

local function field_label(field)
  if field.label and field.label ~= "" then
    return field.label
  end
  return field.key
end

-- ── table column extraction ──────────────────────────────────────────
-- A table field stores its columns in field.options, each a
-- { value, type, label } map. Index is positional (matches the index
-- DB's `col`). Returns a list of { col, ftype, label }.

local function table_columns(field)
  local cols = {}
  for i, opt in ipairs(field.options or {}) do
    if type(opt) == "table" then
      cols[#cols + 1] = {
        col   = i - 1, -- Lua 1-based ipairs -> 0-based index DB column
        ftype = opt.type or "string",
        label = (opt.label and opt.label ~= "" and opt.label)
          or opt.value
          or tostring(i),
      }
    end
  end
  return cols
end

-- ── chart pushers ────────────────────────────────────────────────────

local function push_distribution(charts, tpl, key, col, title)
  local result = formidable.stats.distribution(tpl, key, col)
  if has_categories(result) then
    charts[#charts + 1] = { type = "bar", title = title, result = result }
  end
end

local function push_numeric(charts, tpl, key, col, title)
  local result = formidable.stats.numeric(tpl, key, col, PERCENTILE)
  if has_scalars(result) then
    charts[#charts + 1] = { type = "scalars", title = title, result = result }
  end
end

local function push_timeseries(charts, tpl, key, col, title)
  local result = formidable.stats.timeSeries(tpl, key, "month", col)
  if has_categories(result) then
    charts[#charts + 1] = { type = "line", title = title, result = result }
  end
end

local function push_facet(charts, tpl, key, title)
  local result = formidable.facets.distribution(tpl, key)
  if has_categories(result) then
    charts[#charts + 1] = { type = "bar", title = title, result = result }
  end
end

local function push_cross(charts, tpl, keyA, keyB, title)
  local result = formidable.facets.cross(tpl, keyA, keyB)
  if has_categories(result) then
    charts[#charts + 1] = { type = "stacked", title = title, result = result }
  end
end

-- ── field / column routing ───────────────────────────────────────────

-- Top-level fields: free text/textarea aren't indexed, so only
-- numeric / date / single+multi-choice / boolean route to a chart.
local function route_field(charts, tpl, ftype, key, title)
  if NUMERIC_TYPES[ftype] then
    push_numeric(charts, tpl, key, nil, title)
  elseif ftype == "date" then
    push_timeseries(charts, tpl, key, nil, title)
  elseif DISTRIB_TYPES[ftype] then
    push_distribution(charts, tpl, key, nil, title)
  end
end

-- Table columns: same as fields, but text/string columns ARE indexed
-- (tableRows materialises every non-empty cell), so they distribute.
local function route_column(charts, tpl, ftype, key, col, title)
  if NUMERIC_TYPES[ftype] then
    push_numeric(charts, tpl, key, col, title)
  elseif ftype == "date" then
    push_timeseries(charts, tpl, key, col, title)
  else
    -- string, text, dropdown, radio, boolean - all land in the index
    -- as distributable values for this column.
    push_distribution(charts, tpl, key, col, title)
  end
end

function run(ctx)
  local tpl = ctx and ctx.template
  if not tpl or tpl == "" then
    formidable.toast.warn(formidable.i18n.t("toast.no_template"))
    return { ok = false }
  end

  local t = formidable.template.get(tpl)
  local charts = {}

  -- 1. Facets: a distribution per facet, then cross-tabs over the
  --    unique pairs (capped). Collect keys first so pairs are easy.
  local facet_keys = {}
  for _, facet in ipairs(t.facets or {}) do
    if facet.key and facet.key ~= "" then
      facet_keys[#facet_keys + 1] = facet.key
      push_facet(charts, tpl, facet.key, prefixed("chart.facet", facet.key))
    end
  end

  local cross_count = 0
  for i = 1, #facet_keys do
    for j = i + 1, #facet_keys do
      if cross_count >= MAX_CROSS then break end
      local a, b = facet_keys[i], facet_keys[j]
      push_cross(charts, tpl, a, b, prefixed("chart.cross", a .. " / " .. b))
      cross_count = cross_count + 1
    end
    if cross_count >= MAX_CROSS then break end
  end

  -- 2. Fields: scalar fields by type, plus per-column charts for tables.
  for _, field in ipairs(t.fields or {}) do
    local key, ftype = field.key, field.type
    if key and key ~= "" then
      if ftype == "table" then
        local label = field_label(field)
        for _, c in ipairs(table_columns(field)) do
          route_column(charts, tpl, c.ftype, key, c.col, label .. " / " .. c.label)
        end
      else
        route_field(charts, tpl, ftype, key, prefixed("chart.field", field_label(field)))
      end
    end
  end

  if #charts == 0 then
    formidable.toast.info(formidable.i18n.t("toast.no_data"))
    return { ok = true, charts = {} }
  end

  return { ok = true, charts = charts }
end

-- draw(ctx) is the "Draw chart" form button. ctx carries the form
-- fields: ctx.object (selected statistical object), ctx.shape (chart
-- shape) and ctx.template (active template). It evaluates the object
-- and STEERS the chart widget by pushing a spec via
-- formidable.run.chart - the same live-widget mechanism as
-- run.bar / run.status. The widget (a passive wrapper) renders it.
function draw(ctx)
  local tpl = ctx and ctx.template
  if not tpl or tpl == "" then
    formidable.toast.warn(formidable.i18n.t("toast.no_template"))
    return { ok = false }
  end
  if not ctx.object or ctx.object == "" then
    formidable.toast.info(formidable.i18n.t("toast.no_object"))
    return { ok = true }
  end
  -- Pass the template's facets so the chart colors categories with the
  -- facets' authored option colors (same palette as the facet pills),
  -- instead of the default rotation.
  local t = formidable.template.get(tpl)
  formidable.run.chart({
    type = ctx.shape,
    result = formidable.statistical.eval(tpl, ctx.object),
    facets = t.facets,
  })
  return { ok = true }
end
