-- WikiWonder — render every storage item to Markdown and write it
-- to a target folder on disk.
--
-- Frontmatter handling honours the `plugins:` convention documented
-- in plugin.json. Each plugin reads its own block under that key,
-- so wikiwonder reads plugins.wikiwonder (and Hugo/WordPress/...
-- plugins would read plugins.hugo / plugins.wordpress / ...).
--
-- Per item:
--
--   1. Render markdown via formidable.render.markdown.
--   2. Parse its frontmatter via formidable.fm.parse.
--   3. Look up data.plugins[formidable.plugin.id] (self-describing —
--      no hardcoded "wikiwonder" string in the FM lookup).
--   4. If the block is present:
--        * block.enabled == false  → skip this item entirely.
--        * Output FM = block contents minus the routing keys
--          (`enabled`, `path`). Anything else is passed through.
--        * block.path overrides the default <stem>.md filename and
--          may contain forward slashes for subpath routing.
--   5. If no block is present:
--        * Default: drop the entire (PDF-shaped) frontmatter.
--        * keep_fm_when_no_plugin_block toggle keeps it verbatim.
--   6. Rewrite runtime URLs for disk-hosted wiki use:
--        * /api/images/<stem>/<file>  →  .images/<file>
--        * formidable://t.yaml:d.meta.json#f  →  /<tslug>/<dslug>#f
--      Image basenames stay URL-encoded so the same string works as
--      both the markdown link target and the on-disk filename.
--   7. Compose output via formidable.fm.build and write to disk.
--   8. For every referenced image, copy bytes from storage to
--      <dirname(out_path)>/.images/<file> — i.e. an `.images/` folder
--      next to the .md file, so the relative link in the markdown
--      resolves regardless of grouping (group_by_template, per-item
--      `path` with slashes, …).

-- copy_without omits the named keys from a table (used once below).
local function copy_without(t, keys)
  local out = {}
  local skip = {}
  for _, k in ipairs(keys) do skip[k] = true end
  for k, v in pairs(t) do
    if not skip[k] then out[k] = v end
  end
  return out
end

local function template_stem(t)
  if t.stem and t.stem ~= "" then return t.stem end
  return formidable.path.stripExt(t.filename or "", ".yaml")
end

-- copy_image saves bytes to <md_dir>/.images/<urlname>. md_dir is the
-- parent directory of the .md file the rewrite came from, so the
-- relative `.images/<urlname>` link in the markdown resolves correctly
-- regardless of how the user grouped (per-template, per-item path, …).
local function copy_image(tpl_filename, urlname, md_dir)
  local raw = formidable.url.decode(urlname)
  local ok_b, bytes = pcall(formidable.storage.imageBytes, tpl_filename, raw)
  if not ok_b then
    formidable.log.warn("WikiWonder: imageBytes failed", tpl_filename, raw, tostring(bytes))
    return false
  end
  if bytes == nil or bytes == "" then
    formidable.log.warn("WikiWonder: image not found", tpl_filename, raw)
    return false
  end
  local dest = formidable.path.join(md_dir, ".images", urlname)
  local ok_w, werr = pcall(formidable.fs.write, dest, bytes)
  if not ok_w then
    formidable.log.warn("WikiWonder: image copy failed", dest, tostring(werr))
    return false
  end
  return true
end

local function resolve_out_path(target, tpl_stem, base, plugin_path, group_by_template)
  -- Decide the per-item name component: either the user-supplied
  -- wiki.path or the default base (filename stem).
  local item
  if type(plugin_path) == "string" and plugin_path ~= "" then
    item = formidable.path.stripExt(plugin_path, ".md")
  else
    item = base
  end

  -- An item that already carries a slash routes verbatim under
  -- target (e.g. wiki.path = 'controls/CH.02'). Otherwise group
  -- routing still applies.
  if string.find(item, "/", 1, true) or string.find(item, "\\", 1, true) then
    return formidable.path.join(target, item .. ".md")
  end
  if group_by_template then
    return formidable.path.join(target, tpl_stem, item .. ".md")
  end
  return formidable.path.join(target, item .. ".md")
end

-- emit_markdown returns the markdown string to write, or nil to
-- signal "skip this item". keep_fm controls the fallback when no
-- plugin block is present.
local function emit_markdown(tpl_filename, datafile, keep_fm)
  local data, body = formidable.render.frontmatter(tpl_filename, datafile)
  if data == nil then
    return formidable.fm.build(nil, body), nil
  end
  local block = formidable.fm.pluginBlock(data)
  if type(block) == "table" then
    if block.enabled == false then return nil, nil end
    -- Strip only `enabled` (a control flag, not metadata). `path`
    -- and every other key the user authored stays in the output FM
    -- so wiki targets that use `path`/`permalink`/`slug` see it.
    local out_fm = copy_without(block, { "enabled" })
    return formidable.fm.build(out_fm, body), block
  end
  if keep_fm then
    return formidable.fm.build(data, body), nil
  end
  return formidable.fm.build(nil, body), nil
end

-- find_template returns the template summary for the given filename
-- by scanning formidable.template.list(). Returns nil when no match.
local function find_template(tpl_filename)
  for _, t in ipairs(formidable.template.list() or {}) do
    if t.filename == tpl_filename then return t end
  end
  return nil
end

-- collect_work_for builds the flat (tpl, item) work list for a single
-- template. The work list is built up-front so progress.tick gets a
-- known total — gives the frontend a determinate bar.
local function collect_work_for(t)
  local work = {}
  local tpl_filename = t.filename
  if not tpl_filename or tpl_filename == "" then return work end
  local ok_list, items = pcall(formidable.collection.list, tpl_filename)
  if not ok_list then
    formidable.log.warn("WikiWonder: list failed", tpl_filename, tostring(items))
    return work
  end
  for _, item in ipairs(items or {}) do
    if item.filename and item.filename ~= "" then
      table.insert(work, { tpl = t, item = item })
    end
  end
  return work
end

local function process_one(unit, target, group_by_template, overwrite, keep_fm)
  local tpl_filename = unit.tpl.filename
  local stem = template_stem(unit.tpl)
  local datafile = unit.item.filename
  local base = formidable.path.stripExt(datafile, ".meta.json")

  local ok_emit, out_md, block = pcall(emit_markdown, tpl_filename, datafile, keep_fm)
  if not ok_emit then
    formidable.log.warn("WikiWonder: render failed", tpl_filename, datafile, tostring(out_md))
    return "failed", nil
  end
  if out_md == nil then
    formidable.log.info("WikiWonder: skipped (enabled=false)", tpl_filename, datafile)
    return "skipped", nil
  end

  local rewritten, images = formidable.rewrite.markdown(out_md, {
    template_stem     = stem,
    image_path_prefix = ".images/",
    link_path_format  = "/{tpl}/{data}{hash}",
  })
  out_md = rewritten

  local plugin_path
  if type(block) == "table" then plugin_path = block.path end
  local out_path = resolve_out_path(target, stem, base, plugin_path, group_by_template)

  if (not overwrite) and formidable.fs.exists(out_path) then
    formidable.log.info("WikiWonder: skipped (exists)", out_path)
    return "skipped", out_path
  end
  local ok_write, werr = pcall(formidable.fs.write, out_path, out_md)
  if not ok_write then
    formidable.log.error("WikiWonder: write failed", out_path, tostring(werr))
    return "failed", out_path
  end

  local md_dir = out_path:match("(.*)/[^/]*$") or target
  for urlname, _ in pairs(images) do
    copy_image(tpl_filename, urlname, md_dir)
  end

  formidable.log.info("WikiWonder: wrote", out_path)
  return "wrote", out_path
end

function export(ctx)
  ctx = ctx or {}

  -- The Storage workspace's topbar passes the currently-selected
  -- template's filename via extraCtx. WikiWonder is scoped to that
  -- template only — no whole-storage exports — so a run without
  -- ctx.template is a misuse and surfaces a clear error.
  local tpl_filename = ctx.template
  if type(tpl_filename) ~= "string" or tpl_filename == "" then
    formidable.toast.error("WikiWonder: open from the Storage workspace topbar — no template selected")
    return { ok = false, error = "no_template" }
  end

  local target = ctx.target_folder
  if type(target) ~= "string" or target == "" then
    formidable.toast.error("WikiWonder: target folder is empty")
    return { ok = false, error = "no_target" }
  end

  local tpl_summary = find_template(tpl_filename)
  if tpl_summary == nil then
    formidable.toast.error("WikiWonder: template not found: " .. tpl_filename)
    return { ok = false, error = "template_not_found", template = tpl_filename }
  end

  local overwrite = ctx.overwrite ~= false
  local keep_fm = ctx.keep_fm_when_no_plugin_block == true
  -- group_by_template is preserved for callers that pass it, but
  -- since wikiwonder now exports one template per run, the default
  -- routing (`<target>/<stem>/<base>.md`) already encodes the
  -- template. The Storage-launched flow exports flat into the chosen
  -- folder unless wiki.path overrides per-item.
  local group_by_template = ctx.group_by_template == true

  formidable.log.info("WikiWonder export starting",
    "template=", tpl_filename,
    "target=", target,
    "group_by_template=", tostring(group_by_template),
    "overwrite=", tostring(overwrite),
    "keep_fm_when_no_plugin_block=", tostring(keep_fm))

  local work = collect_work_for(tpl_summary)
  local total = #work
  formidable.run.bar(0, total)
  formidable.run.status("starting")

  local total_written, total_failed, total_skipped = 0, 0, 0
  local cancelled = false

  for i, unit in ipairs(work) do
    -- Cooperative cancel check: pcall around each Go binding (for
    -- per-item failure isolation) would otherwise swallow the
    -- runtime's context-cancel error and keep the loop running.
    -- formidable.cancelled() is a cheap predicate the host updates
    -- when the user clicks Stop in the Run dialog.
    if formidable.cancelled() then
      cancelled = true
      formidable.log.info("WikiWonder: cancelled by user at item", i, "of", total)
      break
    end
    -- Push the current item up first so the user sees what's
    -- starting before we wait on the render/write round-trip.
    formidable.run.status(unit.item.filename or "?")
    local res, _ = process_one(unit, target, group_by_template, overwrite, keep_fm)
    if res == "wrote" then total_written = total_written + 1
    elseif res == "failed" then total_failed = total_failed + 1
    else total_skipped = total_skipped + 1 end
    formidable.run.bar(i, total)
    -- Brief pause between items so the user can actually read the
    -- live status as it ticks past. Stop still preempts during
    -- the sleep (context-cancel wakes it).
    formidable.sleep(0.2)
  end

  local summary = string.format(
    "WikiWonder: wrote %d, skipped %d, failed %d%s",
    total_written, total_skipped, total_failed,
    cancelled and " (cancelled)" or "")
  if cancelled then
    formidable.toast.info(summary)
  elseif total_failed > 0 then
    formidable.toast.warn(summary)
  else
    formidable.toast.success(summary)
  end

  return {
    ok = (total_failed == 0) and (not cancelled),
    target = target,
    written = total_written,
    skipped = total_skipped,
    failed = total_failed,
    cancelled = cancelled,
  }
end
